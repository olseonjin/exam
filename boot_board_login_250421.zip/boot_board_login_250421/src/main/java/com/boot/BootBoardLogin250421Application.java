package com.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootBoardLogin250421Application {

	public static void main(String[] args) {
		SpringApplication.run(BootBoardLogin250421Application.class, args);
	}

}
