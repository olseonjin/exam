package com.boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootBoardLogin250421ApplicationTests {

	@Test
	void contextLoads() {
	}

}
