package com.lgy.item_jdbc_oracle.util;

import org.springframework.jdbc.core.JdbcTemplate;

public class Constant {
//	JdbcTemplate 사용하기 위한 참조변수 추가
	public static JdbcTemplate template;
}
